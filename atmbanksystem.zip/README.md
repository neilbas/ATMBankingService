ATM Banking System for Information Management 2 G7


Gantt Chart (https://cebuinstituteoftechnology-my.sharepoint.com/:x:/g/personal/neiladrian_bas_cit_edu/EZUPooZOATVJrrviavX2LR0BNo5yqEHJhvws-QAekix1tQ?e=RfA3eG)
Design Mock up (https://www.figma.com/design/UoeueHRgsErzORp3AXi6e3/BankingSystem?node-id=0-1&t=Tnx18gkL5NJ4rhih-1)
